# Prosjekt-repo for TDT4100

Dette repoet inneholder et grunnoppsett for et prosjekt som bruker Java, JavaFX og JUnit5.

For å kode prosjektet, kan du enten importere det fra url-en til dette repoet i Eclipse, eller du kan forke det til et eget repo, som du deretter kan importere og bruke.
Sistnevnte gir mulighet til å bruke git for kodesynkronisering og versjonskontroll, og er absolutt anbefalt, spesielt om dere er to som jobber sammen på prosjektet.
Videoer for begge måter å importere repoet ligger på Blackboard.
